create table pam_mhfscall
(
INTERNALSECID varchar(9),
STARTDATE date,
TYPEX char(1),
ENDDATE date,
PRICE decimal(25,25),
EXPECTED int(3),
BATCH_ID varchar(20),
PRIMARY KEY (INTERNALSECID,STARTDATE,TYPEX)
);
