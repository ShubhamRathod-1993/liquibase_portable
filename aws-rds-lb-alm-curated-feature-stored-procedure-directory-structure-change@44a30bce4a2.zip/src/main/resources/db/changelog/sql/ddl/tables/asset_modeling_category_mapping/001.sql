
CREATE TABLE `asset_modeling_category_mapping` (
  `FILE` varchar(20) NOT NULL DEFAULT '',
  `CATEGORY` int(11) DEFAULT NULL,
  `DESCRIPTION` varchar(50) DEFAULT NULL,
  `BATCH_ID` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`FILE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
