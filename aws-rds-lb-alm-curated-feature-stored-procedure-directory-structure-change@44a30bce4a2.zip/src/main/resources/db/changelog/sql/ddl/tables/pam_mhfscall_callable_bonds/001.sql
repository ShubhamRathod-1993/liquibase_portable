create table pam_mhfscall_callable_bonds
(
INTERNALSECID varchar(9),
BEG_CALL_DATE date,
END_CALL_DATE date,
PRICE decimal(25,25),
MON_BW_CALL_OPT int(3),
BATCH_ID varchar(20),
PRIMARY KEY (INTERNALSECID,BEG_CALL_DATE)
);
