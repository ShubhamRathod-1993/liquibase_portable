CREATE TABLE `asset_modeling_sp_code_mapping` (
  `FILE` varchar(20) NOT NULL DEFAULT '',
  `SP_CODE` int(11) DEFAULT NULL,
  `DESCRIPTION` varchar(50) DEFAULT NULL,
  `BATCH_ID` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`FILE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;