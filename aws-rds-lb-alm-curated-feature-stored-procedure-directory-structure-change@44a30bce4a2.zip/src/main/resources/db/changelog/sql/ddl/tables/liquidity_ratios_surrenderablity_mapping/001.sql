CREATE TABLE `liquidity_ratios_surrenderablity_mapping` (
  `SURRENDER_TYPE` varchar(40) NOT NULL DEFAULT '',
  `SURRENDER_VALUE` varchar(40) DEFAULT NULL,
  `BATCH_ID` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`SURRENDER_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
