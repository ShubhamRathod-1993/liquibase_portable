CREATE TABLE `liquidity_ratios_asset_category_mapping` (
  `CATEGORY` varchar(200) NOT NULL DEFAULT '',
  `ENTITY_TYPE` varchar(10) NOT NULL DEFAULT '',
  `BASIS` varchar(20) NOT NULL DEFAULT '',
  `BATCH_ID` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`CATEGORY`,`ENTITY_TYPE`,`BASIS`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
