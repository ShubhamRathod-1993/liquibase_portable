DROP PROCEDURE IF EXISTS ASSETS_MODELING_CREATE_TABLE //
CREATE PROCEDURE `ASSETS_MODELING_CREATE_TABLE`(IN QUARTER_END_DATE DATE)
BEGIN
 DROP TABLE IF EXISTS alm_curated_work.asset_modeling_temp;
CREATE table alm_curated_work.asset_modeling_temp as
SELECT
   '*' AS '!2'
 , T4.SEGMENT
 , T4.COMPANY
 , T4.FILE
 , T4.PORTGROUP
 , T4.AVAL_DATE
 , T4.ASSET_IDENT
 , T4.ASSET_TYPE
 , T4.PORTFOLIO
 , T4.POOL
 , T4.CATEGORY
 , T4.AVR_COMPONENT
 , T4.AVR_CATEGORY
 , T4.SP_CODE
 , T4.BASIS_FLAG
 , T4.ASSET_SCALAR
 , T4.ECONOMY
 , T4.REDEMP_AMT
 , T4.REDEMP_YEAR
 , T4.REDEMP_MONTH
 , T4.REDEMP_DAY
 , T4.COUPON_PC
 , T4.COUPON_FREQ
 , T4.SPREAD_BAND
 , T4.I_MV
 , T4.I_ABV
 , T4.I_ACCI
 , T4.AMORT_TYPE
 , T4.EMBEDDED_OPTION
 , T4.OPTION_ST_YEAR
 , T4.OPTION_ST_MTH
 , T4.OPTION_END_YEAR
 , T4.OPTION_END_MTH
 , T4.OPTION_PERIOD_M
 , T4.AMORT_TERM_M
 , T4.OPT_PREM_TYPE
 , T4.INIT_OPT_PREM_PC
 , T4.REPAY_TYPE
 , T4.ORIG_TERM_Y
 , T4.REPAY_FLAG
 , T4.INT_TERM_M
 , T4.REF_RATE_PROP_PC
 , T4.REF_RATE_MARGIN_PC
 , T4.PBR_WAL_Y
 , CASE WHEN T4.EXCEPTION_REASON IS NOT NULL THEN 'ASSETS_BONDS_EXCEPTION'
		ELSE T4.OUTPUT_FILE_NAME
   END AS 'OUTPUT_FILE_NAME'
 , T4.EXCEPTION_REASON
 , T4.SOFT_EXCEPTION_REASON
 FROM (
SELECT
   T3.*
 , CASE WHEN T3.COAGROUPNUMBER IN (41, 42, 81, 82, 110, 112, 113, 114, 116) THEN 'ASSETS_SCHBA'
		WHEN T3.COAGROUPNUMBER IN (60, 61, 62, 63, 64, 65, 109) THEN 'ASSETS_CASH'
        WHEN T3.PORTGROUP LIKE 'Z%' THEN 'ASSETS_BONDS_ZZZ'
        WHEN T3.FILE = 'Stk' THEN 'ASSETS_BONDS_STK'
        WHEN T3.FILE = 'Fut' THEN 'ASSETS_BONDS_FUT'
        WHEN T3.FILE = 'Opt' THEN 'ASSETS_BONDS_OPT'
        WHEN T3.FILE = 'Swp' THEN 'ASSETS_BONDS_SWP'
        ELSE concat('ASSETS_BONDS_',T3.PORTGROUP)
   END AS 'OUTPUT_FILE_NAME'
 , CASE WHEN (T3.PORTGROUP NOT LIKE 'Z%') AND (T3.FILE NOT IN ('Fut','Opt','Stk','Swp')) THEN
   CASE WHEN isnull(T3.PORTGROUP) THEN 'Portfolio not found on PORTFOLIO_GROUP lookup table'
		WHEN isnull(T3.CATEGORY) THEN 'FILE not found on CATEGORY lookup table'
		WHEN ((T3.I_MV < 100) OR (T3.I_ABV < 100)) THEN 'Book Value or Market Value < 100'
        WHEN isnull(T3.SP_CODE) THEN 'FILE not found on SP_CODE lookup table'
        WHEN T3.AVR_CATEGORY = 0
				THEN 'AVR_CATEGORY = 0 and the asset is not Options, Futures, Common Stock or Preferred Stock'
        WHEN isnull(T3.SPREAD_BAND) THEN 'FILE/AVR_CATEGORY not found on SPREAD_BAND lookup table'
        WHEN ((isnull(T3.REDEMP_YEAR) OR isnull(T3.REDEMP_MONTH) OR isnull(T3.REDEMP_DAY))
            AND T3.COAGROUPNUMBER NOT IN (41,42,81,82,110,112,113,114,116,60,61,62,63,64,65,109))
            THEN 'Redemption Date cannot be null for assets that are not Cash or Short Term'
		WHEN (T3.COUPON_PC < 0) THEN 'COUPON_PC cannot be negative'
        WHEN (T3.COUPON_FREQ = 0 AND T3.FILE <> 'SS_CMO_SL') THEN 'No Coupon Payment'
		WHEN T3.AVR_CATEGORY = 11 THEN concat('AVR_CATEGORY Invalid - Lookup value = ', T3.AVR_CATEGORY_LKUP, 'Manual => ask AIP for credit rating')
        WHEN T3.EXCLUDE_CUSIP is NOT NULL THEN 'PAM_PERIOD/CUSIP Found on Exclusion Table'
        WHEN T3.CALLABLE = 'Y' AND T3.BEG_CALL_DATE IS NULL THEN 'Callable Bond not found on PAM MHFSCALL Table'
		ELSE NULL
   END
   ELSE null
   END AS 'EXCEPTION_REASON'
FROM (
SELECT
     T2.*
   , CASE WHEN T2.AVR_CATEGORY NOT IN (1,2) AND T2.PORTGROUP_T1 = 'ASU' THEN 'AJSU'
		  WHEN T2.AVR_CATEGORY NOT IN (1,2) AND T2.PORTGROUP_T1 = 'NSU' THEN 'NJSU'
          ELSE T2.PORTGROUP_T1
     END AS 'PORTGROUP'
FROM (
SELECT
   T1.*
 , CASE WHEN T1.FILE LIKE '%FR'     THEN 21  /*FLOATING RATE*/
        WHEN T1.FILE = 'SS_CMO_SL'  THEN 22  /*'SS_CMO_SL' */
        WHEN T1.FILE = 'MBS'        Then 22  /*'MBS'*/
        ELSE 11
   END  AS 'ASSET_TYPE'
 , (SELECT cat.CATEGORY FROM alm_curated.asset_modeling_category_mapping cat
          WHERE cat.FILE = CONVERT(T1.FILE, CHAR CHARACTER SET utf8mb4)
   ) AS 'CATEGORY'
 , CASE WHEN T1.FILE IN ('Fut','Opt','Stk') THEN 0
        ELSE IFNULL(T1.AVR_CATEGORY_T1,11)
   END AS 'AVR_CATEGORY'
 , (SELECT spcode.SP_CODE FROM alm_curated.asset_modeling_sp_code_mapping spcode
          WHERE spcode.FILE = CONVERT(T1.FILE, CHAR CHARACTER SET utf8mb4)
   ) AS 'SP_CODE'
 , CASE WHEN T1.PRINCIPALTYPE = 'Perpetual' THEN 2099
		ELSE YEAR(T1.MATURITYDATE)
   END AS 'REDEMP_YEAR'
 , CASE WHEN T1.PRINCIPALTYPE = 'Perpetual' THEN 12
		ELSE MONTH(T1.MATURITYDATE)
   END AS 'REDEMP_MONTH'
 , CASE WHEN T1.PRINCIPALTYPE = 'Perpetual' THEN 30
		ELSE IF(DAY(T1.MATURITYDATE) = 31, 30, DAY(T1.MATURITYDATE))
   END AS 'REDEMP_DAY'
 , CASE WHEN T1.AVR_CATEGORY_T1 = 11 THEN 0
        ELSE (SELECT spband.SPREAD_BAND FROM alm_curated.asset_modeling_spread_band_mapping spband
              WHERE spband.FILE = CONVERT(T1.FILE, CHAR CHARACTER SET utf8mb4)
			    AND spband.AVR_CATEGORY = CASE WHEN T1.FILE IN ('Fut','Opt','Stk') THEN 0
											   ELSE T1.AVR_CATEGORY_T1
									      END
             )
   END AS 'SPREAD_BAND'
 , CASE WHEN T1.FILE LIKE '%SF'    THEN 1    /*SINKING FUND*/
        WHEN T1.FILE = 'SS_CMO_SL' THEN 2    /*'SS_CMO_SL' */
        WHEN T1.FILE = 'MBS'       Then 2    /*'MBS'*/
        ELSE 0
   END  AS 'REPAY_TYPE'
 , CASE
     WHEN T1.CALLABLE = 'Y' THEN '3'
     ELSE '0'
   END AS 'OPT_PREM_TYPE'
 , CASE
     WHEN T1.CALLABLE = 'Y' THEN (T1.PRICE - 100)
	 ELSE 0
   END AS 'INIT_OPT_PREM_PC'
 , CASE
     WHEN T1.CALLABLE = 'Y' THEN '1'
     ELSE '0'
  END AS 'EMBEDDED_OPTION'
, CASE
     WHEN T1.CALLABLE = 'Y' THEN YEAR(T1.BEG_CALL_DATE)
     ELSE '999'
  END AS 'OPTION_ST_YEAR'
, CASE
     WHEN T1.CALLABLE = 'Y' THEN MONTH(T1.BEG_CALL_DATE)
     ELSE '12'
  END AS 'OPTION_ST_MTH'
, CASE
     WHEN T1.CALLABLE = 'Y' AND T1.BEG_CALL_DATE <> T1.END_CALL_DATE THEN YEAR(T1.END_CALL_DATE)
     WHEN T1.CALLABLE = 'Y' AND T1.BEG_CALL_DATE = T1.END_CALL_DATE AND T1.PRICE = 100 THEN YEAR(T1.EFFECTIVEMATDATE)
     ELSE '999'
  END AS 'OPTION_END_YEAR'
, CASE
     WHEN T1.CALLABLE = 'Y' AND T1.BEG_CALL_DATE <> T1.END_CALL_DATE THEN MONTH(T1.END_CALL_DATE)
     WHEN T1.CALLABLE = 'Y' AND T1.BEG_CALL_DATE = T1.END_CALL_DATE AND T1.PRICE = 100 THEN MONTH(T1.EFFECTIVEMATDATE)
     ELSE '12'
  END AS 'OPTION_END_MTH'
, CASE
    WHEN T1.CALLABLE = 'Y' THEN T1.MON_BW_CALL_OPT
    ELSE 999
   END AS 'OPTION_PERIOD_M'
 , CASE
    WHEN T1.CALLABLE = 'Y' THEN PERIOD_DIFF(EXTRACT(YEAR_MONTH FROM T1.EFFECTIVEMATDATE), EXTRACT(YEAR_MONTH FROM T1.PAM_PERIOD))
    ELSE '999'
   END AS 'AMORT_TERM_M'
 , CASE WHEN T1.ASSET_IDENT REGEXP '^[0-9]+E{1}[0-9]+$' THEN concat('CUSIP SCIENTIFIC NOTATION - ', T1.ASSET_IDENT)
	    WHEN T1.PRINCIPALTYPE = 'Perpetual' THEN 'PRINCIPALTYPE = Perpetual'
        ELSE null
   END  AS 'SOFT_EXCEPTION_REASON'
FROM (
SELECT '1' AS 'SEGMENT'
, CASE
	WHEN sp.PORTFOLIO < '8000' THEN 'ALIC'
    ELSE 'ALNY'
  END AS 'COMPANY'
, CASE              /*MAJORTYPE*/
  WHEN sm.MAJORTYPE = "30" Or sm.MAJORTYPE = "40" THEN "Stk"  /*Common & Preferred Stock*/
  WHEN sm.MAJORTYPE = "60" THEN "Opt" 					      /*Options*/
  WHEN sm.MAJORTYPE = "70" THEN "Fut" 					      /*Futures*/
  WHEN sm.MAJORTYPE = "80" THEN "Swp" 						  /*Interest Rate Swaps*/
  ELSE
    /*DEALNUMBER*/
	CASE WHEN sm.DEALNUMBER <> '' THEN
		  CASE                /*Structured Security MAJORTYPE*/
			WHEN sm.MAJORTYPE = "25" OR sm.MAJORTYPE = "26" THEN
				CASE                /*Structured Security PRINCIPALTYPE*/
					WHEN sm.PRINCIPALTYPE = 'Level P & I' THEN  'SS_CMO_SL'   /*Structured Securities/CMO/Student Loan*/
					ELSE '1mickey'                /*Structured Security Fallout*/
				END                /*Structured Security PRINCIPALTYPE*/
			ELSE
				CASE                /*ARM_MBS COUPONTYPE*/
					WHEN sm.COUPONTYPE = 'Adjustable' Then 'ARM'
					WHEN sm.COUPONTYPE = 'Fixed' Then 'MBS'
					ELSE '2mickey'                /*ARM_MBS Fallout*/
				END                /*ARM_MBS COUPONTYPE*/
			END                /*Structured Security MAJORTYPE*/
	   ELSE                /*DEALNUMBER IS NULL*/
		 CASE                /*PRINCIPALTYPE*/
			WHEN sm.PRINCIPALTYPE = 'Level P & I' THEN     /*'MBS'	*/
				CASE               /*ARM_MBS COUPONTYPE*/
					WHEN sm.COUPONTYPE = 'Adjustable' Then 'ARM'
					WHEN sm.COUPONTYPE = 'Fixed' Then 'MBS'
					ELSE '3mickey'                /*ARM_MBS Fallout*/
				END                /*ARM_MBS CouponType*/
			WHEN sm.PRINCIPALTYPE = 'Scheduled Payments' THEN
				CASE                /*ISCALLABLE*/
					WHEN sm.ISCALLABLE = 1 Then
						CASE                /*Callable Sinking Fund LEGALSTATUSCODE*/
							WHEN sm.LEGALSTATUSCODE = 10 Then  'PCSF'  /*Public Callable Sinking Fund*/
							WHEN sm.LEGALSTATUSCODE = 20 Then  'TPCSF'  /*True Private Placement  Callable Sinking Fund*/
							WHEN sm.LEGALSTATUSCODE = 50 Then  'HMCSF' /*Highly Marketable  Callable Sinking Fund*/
							ELSE '4mickey'                			/*Callable Sinking Fund LegalStatusCode Fallout*/
						END                /*Callable Sinking Fund LegalStatusCode*/
					WHEN sm.ISCALLABLE = 0 Then
						CASE                /*Non-Callable Sinking Fund LEGALSTATUSCODE*/
							WHEN sm.LEGALSTATUSCODE = 10 Then  'PSF'  /*Public Sinking Fund*/
							WHEN sm.LEGALSTATUSCODE = 20 Then  'TPSF'  /*True Private Placement Sinking Fund*/
							WHEN sm.LEGALSTATUSCODE = 50 Then  'HMSF' /*Highly Marketable Sinking Fund*/
							ELSE '5mickey'                			/*Non-Callable Sinking Fund LegalStatusCode Fallout*/
						END                /*Non-Callable Sinking Fund LegalStatusCode*/
					ELSE '6mickey'  /*ISCALLABLE Fallout*/
				END                /*ISCALLABLE*/
			WHEN sm.PRINCIPALTYPE = 'Bullet' OR sm.PRINCIPALTYPE = 'Perpetual' OR sm.PRINCIPALTYPE = '' THEN
				CASE                /*COUPONTYPE*/
					WHEN sm.COUPONTYPE = 'Adjustable' OR sm.COUPONTYPE = 'Floating' OR sm.COUPONTYPE = 'Step' Then
						CASE                /*Floating Rate Note LEGALSTATUSCODE*/
							WHEN sm.LEGALSTATUSCODE = 10 Then  'PFR'  /*Public Floating Rate Note*/
							WHEN sm.LEGALSTATUSCODE = 20 Then  'TPFR'  /*True Private Placement Floating Rate Note*/
							WHEN sm.LEGALSTATUSCODE = 50 Then  'HMFR' /*Highly Marketable Floating Rate Note*/
							ELSE '7mickey'                /*Floating Rate LegalStatusCode Fallout*/
						END                /*Floating Rate LegalStatusCode*/
					WHEN sm.COUPONTYPE = 'Fixed' Then
						CASE                /*ISCALLABLE*/
							WHEN sm.ISCALLABLE = 1 Then
								CASE                /*Callable Bond LEGALSTATUSCODE*/
									WHEN sm.LEGALSTATUSCODE = 10 Then  'PCB'  /*Public Callable Bond*/
									WHEN sm.LEGALSTATUSCODE = 20 Then  'TPCB'  /*True Private Placement  Callable Bond*/
									WHEN sm.LEGALSTATUSCODE = 50 Then  'HMCB' /*Highly Marketable  Callable Bond*/
									ELSE '8mickey'                /*Callable Bond LegalStatusCode Fallout*/
								END                /*Callable Bond LegalStatusCode*/
							WHEN sm.ISCALLABLE = 0 Then
								CASE
									WHEN sm.LEGALSTATUSCODE = 10 Then  'PNC' /*Public Non-Callable Bond*/
									WHEN sm.LEGALSTATUSCODE = 20 Then  'TPNC' /*True Private Placement Non-Callable Bond*/
									WHEN sm.LEGALSTATUSCODE = 50 Then  'HMNC' /*Highly Marketable Non-Callable Bond*/
									ELSE '9mickey'                /*Non-Callable Bond LegalStatusCode Fallout*/
								END                /*Non-Callable Bond LegalStatusCode*/
							ELSE '10mickey'                /*ISCALLABLE Fallout*/
						END                /*ISCALLABLE*/
					ELSE '11mickey'  /*COUPONTYPE Fallout=>  (Options; Futures; Common Stock; Mutual Funds; Other Short-Term Assets)*/
				END                /*COUPONTYPE*/
			ELSE '12mickey'                /*PRINCIPALTYPE Fallout*/
		END                /*PRINCIPALTYPE*/
    END       /*DEALNUMBER*/
END   AS  'FILE'     /*MAJORTYPE*/
,sm.PAM_PERIOD AS 'AVAL_DATE'
, CONVERT(sm.SECURITYID,CHAR) AS 'ASSET_IDENT'
, sp.PORTFOLIO
, CASE
     WHEN sp.PORTFOLIO IN ('8010','8011') THEN '2'
     ELSE '1'
  END AS 'POOL'
, '1'  AS 'AVR_COMPONENT'
, (SELECT avrcat.AVR_CATEGORY FROM alm_curated.asset_modeling_avr_category_mapping avrcat
          WHERE avrcat.ALTRATINGFINAL_NAICDESIGNATION =
				  CASE WHEN onr.NEW_NAIC_RATING IS NOT NULL THEN onr.NEW_NAIC_RATING
                       WHEN sp.ALTRATINGFINAL <> '' THEN sp.ALTRATINGFINAL
					   ELSE sm.NAICDESIGNATION
                  END
   ) AS 'AVR_CATEGORY_T1'
, CASE WHEN onr.NEW_NAIC_RATING IS NOT NULL THEN onr.NEW_NAIC_RATING
       WHEN sp.ALTRATINGFINAL <> '' THEN sp.ALTRATINGFINAL
       ELSE sm.NAICDESIGNATION
  END  AS 'AVR_CATEGORY_LKUP'
, (SELECT portgrp.PORTGROUP FROM alm_curated.asset_modeling_portfolio_group_mapping portgrp
          WHERE portgrp.PORTFOLIO = sp.PORTFOLIO
   ) AS 'PORTGROUP_T1'
, '1'  AS 'BASIS_FLAG'
, '1'  AS 'ASSET_SCALAR'
, 'GNL'  AS 'ECONOMY'
, SUM(sp.UNITS) AS 'REDEMP_AMT'
, sm.COUPON AS 'COUPON_PC'
, CASE
	WHEN sm.COUPONFREQ = 'A' THEN '1'
    WHEN sm.COUPONFREQ = 'S' THEN '2'
    WHEN sm.COUPONFREQ = 'Q' THEN '4'
    WHEN sm.COUPONFREQ = 'M' THEN '12'
    WHEN sm.COUPON     = 0   THEN '1'
    ELSE '0'
   END AS 'COUPON_FREQ'
, SUM(sp.MARKETVALUE) AS 'I_MV'
, SUM(sp.BOOKVALUE)   AS 'I_ABV'
, SUM(sp.ACCRUEDINTEREST) AS 'I_ACCI'
, '1' AS 'AMORT_TYPE'
, '999' AS 'ORIG_TERM_Y'
, '999' AS 'REPAY_FLAG'
, '999' AS 'INT_TERM_M'
, '999' AS 'REF_RATE_PROP_PC'
, '999' AS 'REF_RATE_MARGIN_PC'
, sp.WEIGHTEDAVERAGELIFE AS 'PBR_WAL_Y'
, sm.MATURITYDATE
, sm.EFFECTIVEMATDATE
, sm.COAGROUPNUMBER
, sm.PRINCIPALTYPE
, sm.MAJORTYPE
, sm.PAM_PERIOD
, cb.BEG_CALL_DATE
, cb.END_CALL_DATE
, cb.PRICE
, cb.MON_BW_CALL_OPT
-- , '99' MON_BW_CALL_OPT
, CASE WHEN sm.ISCALLABLE = 1 AND sm.COUPONTYPE = 'Fixed' AND sm.PRINCIPALTYPE <> 'Level P & I'
			THEN 'Y'
	   ELSE 'N'
   END AS 'CALLABLE'
, (SELECT excusip.CUSIP_TO_EXCLUDE FROM alm_curated.asset_modeling_excluded_cusips excusip
          WHERE excusip.PAM_PERIOD = sm.PAM_PERIOD
            AND excusip.CUSIP_TO_EXCLUDE = sm.SECURITYID
   ) AS 'EXCLUDE_CUSIP'
FROM alm_curated.liquidity_ratios_pam_security_master sm
INNER JOIN alm_curated.liquidity_ratios_pam_security_position sp
ON sm.SECURITYID = sp.SECURITYID
AND sm.PAM_PERIOD = sp.PAM_PERIOD
AND sm.PAM_PERIOD = QUARTER_END_DATE
AND sp.COSTBASIS = 'STAT'
AND sp.PORTFOLIO >= '7000'

LEFT JOIN alm_curated.asset_modeling_override_naic_rating onr
ON  onr.CUSIP = sm.SECURITYID
AND onr.PAM_PERIOD = sm.PAM_PERIOD

LEFT JOIN alm_curated.pam_mhfscall_callable_bonds cb
ON  cb.INTERNALSECID = sm.INTERNALSECID

group by sp.PAM_PERIOD, sm.SECURITYID, sp.PORTFOLIO, sm.COUPON
) T1
) T2
) T3
) T4
order by CASE WHEN T4.EXCEPTION_REASON IS NOT NULL THEN 'ASSETS_BONDS_EXCEPTION'
			  ELSE T4.OUTPUT_FILE_NAME
          END
		, T4.AVAL_DATE, T4.ASSET_IDENT, T4.PORTFOLIO, T4.COUPON_PC
;

END //
