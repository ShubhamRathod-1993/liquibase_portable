DROP VIEW IF EXISTS vw_portfolio_calc_grp_mapping //
CREATE ALGORITHM=UNDEFINED DEFINER=`f_alm`@`%` SQL SECURITY DEFINER VIEW `vw_portfolio_calc_grp_mapping` AS (select `portfolio_calc_grp_mapping`.`PORTFOLIO_NAME` AS `PORTFOLIO_NAME`,`portfolio_calc_grp_mapping`.`PORTFOLIO_GROUP_NAME` AS `PORTFOLIO_GROUP_NAME`,`portfolio_calc_grp_mapping`.`CA_GROUPS` AS `CA_GROUPS`,`portfolio_calc_grp_mapping`.`BATCH_ID` AS `BATCH_ID` from `portfolio_calc_grp_mapping`);

