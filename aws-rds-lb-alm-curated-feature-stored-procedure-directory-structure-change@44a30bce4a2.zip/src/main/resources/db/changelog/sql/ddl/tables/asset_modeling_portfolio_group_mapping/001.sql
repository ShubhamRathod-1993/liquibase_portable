CREATE TABLE `asset_modeling_portfolio_group_mapping` (
  `PORTFOLIO` varchar(20) NOT NULL DEFAULT '',
  `PORTGROUP` varchar(20) DEFAULT NULL,
  `DESCRIPTION` varchar(80) DEFAULT NULL,
  `BATCH_ID` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`PORTFOLIO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;