DROP VIEW IF EXISTS vw_portfolio_mapping //
CREATE ALGORITHM=UNDEFINED DEFINER=`f_alm`@`%` SQL SECURITY DEFINER VIEW `vw_portfolio_mapping` AS (select `portfolio_mapping`.`PORTFOLIO_NAME` AS `PORTFOLIO_NAME`,`portfolio_mapping`.`PORTFOLIO_GROUP_NAME` AS `PORTFOLIO_GROUP_NAME`,`portfolio_mapping`.`BATCH_ID` AS `BATCH_ID` from `portfolio_mapping`);

