DROP VIEW IF EXISTS vw_liquidity_ratios_target_ratios //
CREATE ALGORITHM=UNDEFINED DEFINER=`f_alm`@`%` SQL SECURITY DEFINER VIEW `vw_liquidity_ratios_target_ratios` AS (select `liquidity_ratios_target_ratios`.`TARGET_RATIO_FACTOR` AS `TARGET_RATIO_FACTOR`,`liquidity_ratios_target_ratios`.`ENTITY` AS `ENTITY`,`liquidity_ratios_target_ratios`.`TARGET_RATIO` AS `TARGET_RATIO` from `liquidity_ratios_target_ratios`);

