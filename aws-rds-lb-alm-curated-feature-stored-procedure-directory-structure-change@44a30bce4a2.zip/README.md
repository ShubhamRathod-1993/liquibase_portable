## Prerequisites

Docker, JDK 8, Maven

## Running Locally

[Local Environment Setup](https://confluence.ameritas.com/display/DA/Liquibase)

### Running in your system. 

Prerequisites 

```
JDK 8, Maven
```

### Run Dependencies 

```
docker-compose up -d
```

Verify Container Status

```
docker-compose ps -a
```

Run Command
```
mvn spring-boot:run -Dspring-boot.run.profiles=local
```

Note. If you are using docker to run the application then you don't need to install JAVA/Maven in your local machine.


Build Command

```
mvn package
```

### Running in Docker

Prerequisites 

```
Docker
```

Build Image

```
docker build -t aws-rds-lb-common-pipelinelog .
```

Run Container

```
docker run --rm -p 8080:80 \
  -e "DB_HOST=host.docker.internal" \
  -e "DB_PORT=3306" \
  -e "DB_USER=root" \
  -e "DB_PASSWORD=root" \
  aws-rds-lb-common-pipelinelog
```

## Run From Intellij

[How to Run in Intellij](https://confluence.ameritas.com/display/DA/Intellij+-+SpringBoot+Project+Setup)

VM Options

``
-Dspring.profiles.active=local
``

## Liquibase Documentation

[Developer Guide](https://confluence.ameritas.com/display/DA/Liquibase+Developer+Guide)

[Developer Workflow](https://confluence.ameritas.com/display/DA/DFO+-+Developer+Liquibase+Workflow)

[Deployment Workflow](https://confluence.ameritas.com/display/DA/DFO+-+DBA+Liquibase+Deployment+Workflow)