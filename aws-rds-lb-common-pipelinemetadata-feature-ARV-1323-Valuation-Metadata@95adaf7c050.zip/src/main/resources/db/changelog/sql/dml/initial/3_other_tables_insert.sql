insert into pipelinemetadata.FILE_EXTENSION_LIST
(EXTENSION_NM, EXTENSION_TYPE)
values
('csv','False'),
('gpg','False'),
('gz.gpg','True'),
('zip.gz.gpg','True');

insert into pipelinemetadata.DQ_RULE_METADATA
(DQ_RULE_NM, CREATED_DTTM)
values
('date_val', now()),
('time_val', now()),
('decimal_check', now());

insert into pipelinemetadata.CLEANSING_RULE_METADATA
(CLEAN_RULE_NM, CREATED_DTTM)
values
('convert_date', now()),
('convert_timestamp', now()),
('convert_amount', now()),
('convert_number', now()),
('convert_decimal', now()),
('convert_decimal(15,2)', now()),
('convert_decimal(6,3)', now()),
('convert_decimal(14,6)', now()),
('convert_decimal(19,0)', now()),
('convert_decimal(13,6)', now());


