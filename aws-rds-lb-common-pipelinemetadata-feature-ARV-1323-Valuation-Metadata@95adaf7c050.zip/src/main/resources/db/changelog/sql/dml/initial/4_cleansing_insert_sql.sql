insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_date') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where lower(COLUMN_NM) in ('cvm_extract_date',
'cvm_dob_dt') 
and FILE_NM like  '%CVM.ZIP' ;



insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_decimal(19,0)') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where lower(COLUMN_NM) in 
 ('cvm_iss_age',
'cvm_orig_iss_age',
'cvm_je_age_num') 
and FILE_NM like  '%CVM.ZIP' ;



insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_decimal(6,3)') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where lower(COLUMN_NM) in 
 ('cvm_jnt_anu_pct') 
and FILE_NM like  '%CVM.ZIP' ;


insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_timestamp') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where lower(COLUMN_NM) in 
 ('cvm_extract_time') 
and FILE_NM like  '%CVM.ZIP' ;



insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_date') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where lower(COLUMN_NM) in 
 ('mvm_extract_date'
,'mvm_issue_dt'
,'mvm_next_bill_dt'
,'mvm_ptd'
,'mvm_fst_prm_dt'
,'mvm_lst_prm_dt') 
and FILE_NM like  '%MVM.ZIP' ;



insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_decimal(15,2)') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where lower(COLUMN_NM) in 
 ('mvm_1035_amt'
,'mvm_tot_net_prt_la'
,'mvm_tot_prm_amt'
,'mvm_ann_wvr_prem'
,'mvm_pln_prem_amt'
,'mvm_fst_prm_amt'
,'mvm_lst_prm_amt'
,'mvm_grs_prtl_wdl'
,'mvm_grs_cnb_alc'
,'mvm_dmp_in_iss_amt'
) 
and FILE_NM like  '%MVM.ZIP' ;



insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_decimal(19,0)') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where lower(COLUMN_NM) in 
 ('mvm_period_no') 
and FILE_NM like  '%MVM.ZIP' ;


insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_timestamp') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where lower(COLUMN_NM) in 
 ('mvm_extract_time') 
and FILE_NM like  '%MVM.ZIP' ;


insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_decimal(15,2)') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where upper(COLUMN_NM) in (
'PVM_BAS_INFRC_AMT',
'PVM_RDR_INFRC_AMT',
'PVM_NON_LOAN_INT',
'PVM_LOAN_INT_AMT',
'PVM_APM_AMT',
'PVM_CASH_SURR_AMT',
'PVM_TOT_ACC_AMT',
'PVM_FIX_ACC_AMT',
'PVM_LOAN_ACC_AMT',
'PVM_LOAN_PAYF_AMT',
'PVM_SURR_CHG_AMT',
'PVM_TOT_PUA_AMT',
'PVM_ACCR_INT_AMT',
'PVM_ACM_DIV_AMT',
'PVM_MDL_PREM_AMT',
'PVM_CORR_AMT',
'PVM_POL_CUR_CV',
'PVM_PLN_PRM_AMT',
'PVM_PUA_CUR_CV',
'PVM_DBN_RST_AMT',
'PVM_MGDB_RLUP_PRM',
'PVM_TOT_MIN_PREM',
'PVM_PURE_ENDW_AMT',
'PVM_TOT_ACC_AMT_LA',
'PVM_PYOT_PAY_AMT',
'PVM_MIN_PREM_AMT',
'PVM_MIN_REQ_PREM',
'PVM_TGT_PREM_AMT',
'PVM_PREM_LESS_PS',
'PVM_RECORD_AMT',
'PVM_ITD_ACMREQ_PRM',
'PVM_ITD_ACMPD_NPRM',
'PVM_ADJ_CSV_AMT',
'PVM_ADJ_DBN_RST',
'PVM_GRN_CSV_AMT',
'PVM_MVA_AMT',
'PVM_EXC_CHG_AMT',
'PVM_EXC_VAL_AMT',
'PVM_OPTA_SPEC_AMT',
'PVM_OPTB_SPEC_AMT',
'PVM_FNL_GRN_PAY',
'PVM_SCH_WDL_AMT',
'PVM_PREM_RFND_AMT',
'PVM_PRM_ALCFIX_AMT',
'PVM_APR_GRN_BAL',
'PVM_APPR_CHRG',
'PVM_AV_PLUS_APR',
'PVM_RED_LON_AMT',
'PVM_ADJ_TOTACM_AMT',
'PVM_RDR_CHRG_AMT',
'PVM_PREM_RLUP_AMT',
'PVM_MAX_ANV_AMT',
'PVM_GRN_WDL_AMT',
'PVM_REM_WDL_AMT',
'PVM_CY_REM_WDL_AMT',
'PVM_BEN_BASE_AMT',
'PVM_SHADOW_ACC_AMT',
'PVM_LPS_CTCHUP_PRM',
'PVM_DB_OPTC_AD_AMT',
'PVM_SEP_ACC_AMT',
'PVM_EQU_ACC_AMT',
'PVM_LOAN_PRN_AMT',
'PVM_DIV_NEXT_AMT',
'PVM_EPB_BEN_BAS',
'PVM_EEPB_TRANSFER',
'PVM_EPB_EEPB_GMDB',
'PVM_EXPCHG_PRM_AMT',
'PVM_DIS_AMT',
'PVM_ANN_TOT_NF_AMT',
'PVM_ANN_FIX_NF_AMT',
'PVM_ANN_NF_FEE',
'PVM_EQU_ACC_INT',
'PVM_R_CHR_BASIS',
'PVM_TERM_DIV_AMT',
'PVM_R_CHR_ACCUM',
'PVM_OWNSHP_AV',
'PVM_OWNSHP_BEN_AMT',
'PVM_PREM_ON_DEP',
'PVM_PREM_ON_DEPINT',
'PVM_ACM_DIV_INTR',
'PVM_TOT_OYT_AMT',
'PVM_VLOAN_ACC_AMT',
'PVM_PREM_BNS_PRN',
'PVM_PREM_BNS_INT',
'PVM_PREM_BNS_VST',
'PVM_PREM_BNS_NONVST',
'PVM_PREM_BNS_ACC',
'PVM_MVA_ISS_IDX_VAL',
'PVM_MVA_VD_IDX_VAL',
'PVM_ORIG_FACE_AMT',
'PVM_PH_FACE_AMT',
'PVM_TRAD_LOAN_INT',
'PVM_CUML_GUAR_VAL',
'PVM_ITD_PRN_PRTPD',
'PVM_ITD_ACMRQ2_PRM',
'PVM_LPS_CTCHU2_PRM')
and FILE_NM like  '%PVM.ZIP' ;


insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_date') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where upper(COLUMN_NM) in (
'PVM_EXTRACT_DATE',
'PVM_ERROR_DT',
'PVM_ISSUE_DT',
'PVM_ET_EXP_DT',
'PVM_1_PAY_DT',
'PVM_NXT_PAY_DT',
'PVM_MP_ACM_TO_DT',
'PVM_ORIG_ISS_DT',
'PVM_FNL_PAY_DT',
'PVM_WDL_ELECTN_DT',
'PVM_CUR_PHASE_DT',
'PVM_LOAN_INT_PTD',
'PVM_DIS_DT',
'PVM_R_CHR_RESET_DT',
'PVM_P_RLUP_STR_DT',
'PVM_UW_STAT_CHG_DT',
'PVM_OWNSHP_CHG_DT',
'PVM_BOOST_STR_DT',
'PVM_MVA_RT_EXP_DT')
and FILE_NM like  '%PVM.ZIP' ;


insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_decimal(19,0)') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where upper(COLUMN_NM) in (
'PVM_ISS_AGE',
'PVM_PART_CNT',
'PVM_PAY_PER_YR_CD',
'PVM_NUM_GRN_PAY_RM',
'PVM_BEN_PER_NO',
'PVM_ANTIC_PYMT_MOS',
'PVM_MDL_FCTR',
'PVM_DIS_AGE',
'PVM_PREM_RLUP_PER',
'PVM_R_CHR_RFND_PER')
and FILE_NM like  '%PVM.ZIP' ;


insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_decimal(6,3)') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where upper(COLUMN_NM) in (
'PVM_GWA_DST_FAC_NO',
'PVM_SURR_CHG_PCT',
'PVM_CUR_LB_CHG_RTE',
'PVM_ANN_NF_PRM_FCT',
'PVM_ANN_NF_RTE',
'PVM_PREM_RLUP_RT',
'PVM_P_RLUP_MDL_RT',
'PVM_GLWB_IDXPAR_RT')
and FILE_NM like  '%PVM.ZIP' ;




insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_timestamp') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where upper(COLUMN_NM) in (
'PVM_EXTRACT_TIME')
and FILE_NM like  '%PVM.ZIP' ;




insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_decimal(15,2)') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where lower(COLUMN_NM) in (
'rvm_ann_grs_prm',
'rvm_mdl_grs_prm',
'rvm_csh_val_amt',
'rvm_pua_csh_val',
'rvm_oyt_csh_val',
'rvm_perm_extr_prm',
'rvm_tmp_extr_prm',
'rvm_curr_face_amt',
'rvm_perm_extr_prm2',
'rvm_tmp_extr_prm2',
'rvm_tbl_rtg_prm',
'rvm_tbl_rtg_prm2',
'rvm_unit_face_amt')
and FILE_NM like  '%RVM.ZIP' ;


insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_date') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where lower(COLUMN_NM) in (
'rvm_extract_date',
'rvm_term_dt',
'rvm_pua_term_dt',
'rvm_oyt_term_dt',
'rvm_iss_dt',
'rvm_tmp_prm_exp_dt',
'rvm_tmp_prm_expdt2',
'rvm_orig_iss_dt')
and FILE_NM like  '%RVM.ZIP' ;



insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_decimal(13,6)') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where lower(COLUMN_NM) in (
'rvm_unit_no',
'rvm_pua_ern_unt_no',
'rvm_oyt_unit_no'
)
and FILE_NM like  '%RVM.ZIP' ;


insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_decimal(6,3)') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where lower(COLUMN_NM) in (
'rvm_pmt_rtg_pct',
'rvm_pmt_rtg_pct2'
)
and FILE_NM like  '%RVM.ZIP' ;


insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_decimal(14,6)') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where lower(COLUMN_NM) in (
'rvm_pua_pur_unt_no')
and FILE_NM like  '%RVM.ZIP' ;




insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_decimal(19,0)') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where lower(COLUMN_NM) in (
'rvm_iss_age')
and FILE_NM like  '%RVM.ZIP' ;




insert into pipelinemetadata.CLEANSING_RULE_COLUMN_METADATA
 Select  (select CLEAN_RULE_ID from pipelinemetadata.CLEANSING_RULE_METADATA WHERE CLEAN_RULE_NM = 'convert_timestamp') as CLEANSING_RULE_ID,
 COLUMN_ID , 'N' as HARD_REJECT_IND, null as REPLACEMENT_VALUE, 'Y' as RULE_ACTIVE_IND ,
 date(now()) as RULE_START_DT, null as RULE_END_DT,
 now() as REC_CREATED_DTM, null as REC_UPDATED_DTTM
  from pipelinemetadata.FILE_COLUMN_METADATA
 where lower(COLUMN_NM) in (
'rvm_extract_time')
and FILE_NM like  '%RVM.ZIP' ;
