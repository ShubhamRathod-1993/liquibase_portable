INSERT INTO CLEANSING_RULE_METADATA  (CLEAN_RULE_NM, CLEAN_RULE_DESC, CREATED_DTTM)
values
('convert_decimal(6,4)', 'for columns of Decimal(6,4)',now()),
('convert_decimal(15,5)', 'for columns of Decimal(15,5)',now()),
('convert_decimal(6,5)', 'for columns of Decimal(6,5)',now()),
('convert_decimal(8,6)', 'for columns of Decimal(8,6)',now());

commit;