## Prerequisites

Docker, JDK 8, Maven

## Running Locally

[Local Environment Setup](https://confluence.ameritas.com/display/DA/Liquibase)

### Running in your system. 

Prerequisites 

```
JDK 8, Maven
```

Run Command
```
mvn spring-boot:run -Dspring-boot.run.profiles=local
```

Note. If you are using docker to run the application then you don't need to install JAVA/Maven in your local machine.


Build Command

```
mvn package
```

### Running in Docker

Prerequisites 

```
Docker
```

Build Image

```
docker build -t liquibase-springboot-sample .
```

Run Container

```
docker run --rm -p 8080:80 \
  -e "DB_HOST=host.docker.internal" \
  -e "DB_PORT=3306" \
  -e "DB_USER=root" \
  -e "DB_PASSWORD=root" \
  template-liquibase-spring-boot-mysql
```






